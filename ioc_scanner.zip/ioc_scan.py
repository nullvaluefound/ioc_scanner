#!/usr/bin/env python3
"""Read-only recursive IOC scanner. Python 3.10+; standard library only.

Keep iocs.json beside this file, or specify --ioc-file. No shell code is run.
Exit 0: no matches; 1: matches; 2: errors/incomplete scan or bad arguments.
"""
from __future__ import annotations

import argparse
import codecs
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
import csv
import fnmatch
import gzip
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import threading
import time
import zlib

# Regex extracts candidates; ipaddress validates and filters public unicast IPs.
OCTET = r'(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])'
IPV4_REGEX = rf'(?<![A-Za-z0-9_.])(?:{OCTET}\.){{3}}{OCTET}(?![A-Za-z0-9_]|\.[0-9])'
# Intentionally broad candidate extraction; IPv6 parsing is done by ipaddress.
IPV6_REGEX = r'(?<![A-Za-z0-9_:.])(?=[0-9A-Fa-f:.]*:[0-9A-Fa-f:.]*:)[0-9A-Fa-f:.]+(?![A-Za-z0-9_:.])'
IP4_STR = re.compile(IPV4_REGEX)
IP6_STR = re.compile(IPV6_REGEX)
IP4_BYTES = re.compile(IPV4_REGEX.encode('ascii'))
IP6_BYTES = re.compile(IPV6_REGEX.encode('ascii'))
FIELDS = ['path', 'line', 'column', 'byte_offset', 'mode', 'kind', 'category',
          'indicator_id', 'indicator', 'match', 'match_hex', 'line_text', 'source_lines',
          'evidence_status', 'source_urls', 'note', 'evidence_lines']


def public_address(address):
    """Global unicast, explicitly excluding multicast and reserved addresses."""
    mapped = getattr(address, 'ipv4_mapped', None)
    if mapped is not None:
        return public_address(mapped)
    return (address.is_global and not address.is_multicast and not address.is_reserved
            and not address.is_loopback and not address.is_link_local
            and not address.is_unspecified)


def ip_candidates(line):
    """Yield validated IPv4/IPv6 addresses with spans; don't split IPv6 into IPv4."""
    is_bytes = isinstance(line, bytes)
    ipv6 = IP6_BYTES if is_bytes else IP6_STR
    ipv4 = IP4_BYTES if is_bytes else IP4_STR
    spans = []
    for match in ipv6.finditer(line):
        value = match.group().decode('ascii') if is_bytes else match.group()
        # A prose period can follow an otherwise valid IPv6 address.
        candidate = value.rstrip('.')
        try:
            address = ipaddress.IPv6Address(candidate)
        except ipaddress.AddressValueError:
            continue
        end = match.start() + len(candidate)
        spans.append((match.start(), end))
        yield address, match.start(), end
    for match in ipv4.finditer(line):
        if any(start <= match.start() < end for start, end in spans):
            continue
        value = match.group().decode('ascii') if is_bytes else match.group()
        yield ipaddress.IPv4Address(value), match.start(), match.end()


def glob_content_pattern(value):
    # Wildcards stay inside a single path token and never consume whitespace.
    return ''.join(r'[^\s/\\\x00"\'<>|]*' if c == '*' else
                   r'[^\s/\\\x00"\'<>|]' if c == '?' else re.escape(c)
                   for c in value)


def indicator_pattern(item):
    value, category = item['value'], item['category']
    if item['kind'] == 'regex':
        return value
    p = glob_content_pattern(value) if item['kind'] == 'glob' else re.escape(value)
    if category.endswith('ipv4'):
        return r'(?<![A-Za-z0-9_.])' + p + r'(?![A-Za-z0-9_]|\.[0-9])'
    if category == 'domain':
        # Allow subdomains, reject lookalike suffixes (example.com.evil).
        return r'(?<![A-Za-z0-9_-])' + p + r'(?![A-Za-z0-9_-]|\.[A-Za-z0-9_-])'
    if 'sha256' in category:
        return r'(?<![0-9a-fA-F])' + p + r'(?![0-9a-fA-F])'
    if category in ('path', 'filename_glob'):
        return r'(?<![A-Za-z0-9_.-])' + p + r'(?![A-Za-z0-9_.-])'
    if category == 'url':
        return r'(?<![A-Za-z0-9_])' + p + r'(?![A-Za-z0-9_./%-])'
    return p


def compile_rules(items, args):
    rules = {'strings': [], 'bytes': []}
    modes = ['strings','bytes'] if args.mode=='both' else [args.mode]
    networks, hashes, path_items = [], {}, []
    for item in items:
        if item.get('enabled') is False:
            continue
        if args.verified_only and item.get('evidence_status') != 'report_confirmed':
            continue
        if item.get('heuristic') and not args.heuristics:
            continue
        if 'sha256' in item['category']:
            hashes.setdefault(item['value'].lower(), []).append(item)
            if not args.hash_text:
                continue
        if item['category'] in ('path', 'filename_glob'):
            path_items.append(item)
            # Filesystem artifacts are never turned into content substrings.
            continue
        if item['kind'] == 'cidr':
            networks.append((ipaddress.ip_network(item['value']), item))
            continue
        pattern = indicator_pattern(item)
        flags = re.IGNORECASE if args.ignore_case or item.get('ignore_case') or item['category'] in ('domain','sha256','vulnerable_component_sha256') else 0
        for mode in modes:
            def compile_pattern(value):
                return re.compile(value if mode == 'strings' else value.encode('utf-8'), flags)
            prepared = dict(item)
            for key in ('line_all', 'line_none', 'file_all'):
                prepared['_'+key] = [compile_pattern(x) for x in item.get(key, [])]
            rules[mode].append((compile_pattern(pattern), prepared))
    for kind, values in [('literal', args.string), ('regex', args.regex)]:
        for n,value in enumerate(values,1):
            item = dict(id=f'custom-{kind}-{n}',category='custom',kind=kind,value=value,source_lines=[])
            pattern = re.escape(value) if kind == 'literal' else value
            for mode in modes:
                rules[mode].append((re.compile(pattern if mode=='strings' else pattern.encode('utf-8'), re.I if args.ignore_case else 0), item))
    for kind, values in [('hex',args.hex),('byte_regex',args.byte_regex)]:
        for n,value in enumerate(values,1):
            pattern = re.escape(bytes.fromhex(value)) if kind=='hex' else value.encode('ascii')
            item = dict(id=f'custom-{kind}-{n}',category='custom_bytes',kind=kind,value=value,source_lines=[])
            rules['bytes'].append((re.compile(pattern, re.I if args.ignore_case else 0),item))
    return rules, networks, hashes, path_items


def display(value):
    # Latin-1 preserves a one-to-one view of byte values; match_hex is exact.
    return value.decode('latin-1') if isinstance(value,bytes) else value


def record(path, mode, kind, item, line=None, number=None, start=None, end=None, offset=None):
    value = line[start:end] if line is not None and start is not None else item['value']
    return dict(path=str(path), line=number, column=start+1 if start is not None else None,
                byte_offset=offset+start if offset is not None and start is not None else None,
                mode=mode, kind=kind, category=item['category'], indicator_id=item['id'],
                indicator=item['value'], match=display(value),
                match_hex=value.hex() if isinstance(value,bytes) else None,
                line_text=display(line).rstrip('\r\n') if line is not None else None,
                source_lines=item.get('source_lines',[]),
                evidence_status=item.get('evidence_status','user_supplied'),
                source_urls=item.get('source_urls',[]), note=item.get('note',''), evidence_lines=[])


def appliance_path(path, args):
    if args.appliance_root is None:
        return None
    try:
        return '/' + path.relative_to(args.appliance_root).as_posix()
    except ValueError:
        return None


def path_glob(value, pattern, ignore_case=False):
    # '*' cannot cross a path separator; '**' can. No arbitrary suffix matching.
    pattern = re.escape(pattern).replace(r'\*\*/', '(?:[^/]+/)*').replace(r'\*\*', '.*').replace(r'\*', '[^/]*').replace(r'\?', '[^/]')
    return re.fullmatch(pattern, value, re.I if ignore_case else 0) is not None


def scope_applies(path, item, args):
    scope = item.get('scope', {})
    virtual = appliance_path(path, args)
    if scope.get('paths') and (virtual is None or not any(
            path_glob(virtual, p, args.ignore_case) for p in scope['paths'])):
        return False
    if scope.get('basenames'):
        patterns = scope['basenames'] + (args.log_glob if scope.get('log') else [])
        name = path.name.casefold() if args.ignore_case else path.name
        if not any(fnmatch.fnmatchcase(name, p.casefold() if args.ignore_case else p) for p in patterns):
            return False
    if scope.get('max_bytes') and path.stat().st_size >= scope['max_bytes']:
        return False
    return True


def content_matches(path, stream, mode, rules, networks, args, stop=None):
    offset = 0
    active = [(regex,item) for regex,item in rules if scope_applies(path,item,args)]
    # Keep just one supporting line per predicate, not all matching file content.
    states = {item['id']: {'anchor': None, 'guards': {}} for _,item in active if item.get('_file_all')}
    for number,line in enumerate(stream, 1):
        if stop is not None and stop.is_set():
            return
        for regex, item in active:
            if any(rx.search(line) for rx in item.get('_line_none', [])):
                continue
            if not all(rx.search(line) for rx in item.get('_line_all', [])):
                continue
            state = states.get(item['id'])
            if state is not None:
                for index, rx in enumerate(item['_file_all']):
                    if index not in state['guards'] and rx.search(line):
                        state['guards'][index] = number
            for match in regex.finditer(line):
                if match.start()==match.end():
                    continue
                result = record(path,mode,'content',item,line,number,match.start(),match.end(),offset if mode=='bytes' else None)
                if state is None:
                    yield result
                elif state['anchor'] is None:
                    state['anchor'] = result
        if args.public_ips or networks:
            for address,start,end in ip_candidates(line):
                if args.public_ips and (args.ip_version=='both' or str(address.version)==args.ip_version) and public_address(address):
                    item=dict(id='public-ip', category=f'public_ipv{address.version}',value=str(address))
                    yield record(path,mode,'public_ip',item,line,number,start,end,offset if mode=='bytes' else None)
                for network,item in networks:
                    if any(re.search(p, display(line)) for p in item.get('line_none', [])):
                        continue
                    if address.version==network.version and address in network:
                        yield record(path,mode,'content',item,line,number,start,end,offset if mode=='bytes' else None)
        if mode=='bytes':
            offset += len(line)
    for _, item in active:
        state = states.get(item['id'])
        if state and state['anchor'] and len(state['guards']) == len(item['_file_all']):
            result = state['anchor']
            result['evidence_lines'] = sorted(set([result['line'], *state['guards'].values()]))
            yield result


def path_matches(path, root, items, args):
    relative = appliance_path(path, args)
    if relative is None:
        return
    for item in items:
        pattern = item['value']
        if not scope_applies(path, item, args):
            continue
        if path_glob(relative,pattern,args.ignore_case) or (item.get('directory') and
                (relative.casefold() if args.ignore_case else relative).startswith(
                    (pattern.casefold() if args.ignore_case else pattern).rstrip('/')+'/')):
            yield record(path,'path','path',item)


def is_link(st):
    # Windows junctions are reparse points; skip these as well as POSIX symlinks.
    return stat.S_ISLNK(st.st_mode) or bool(getattr(st,'st_file_attributes',0) & 0x400)


def iter_files(root, excluded, globs, error, skipped):
    def excluded_by_glob(path):
        relative = path.relative_to(root).as_posix()
        return any(fnmatch.fnmatchcase(relative,p) or fnmatch.fnmatchcase(path.name,p) for p in globs)
    def walk(directory):
        try:
            with os.scandir(directory) as entries:
                for entry in entries:
                    path=Path(entry.path)
                    try:
                        st=entry.stat(follow_symlinks=False)
                        if is_link(st) or excluded_by_glob(path) or path.resolve() in excluded:
                            skipped[0]+=1
                            continue
                        if stat.S_ISDIR(st.st_mode):
                            yield from walk(path)
                        elif stat.S_ISREG(st.st_mode):
                            yield path,st.st_size
                        else:
                            skipped[0]+=1
                    except OSError as exc:
                        error(path,exc)
        except OSError as exc:
            error(directory,exc)
    yield from walk(root)


class Reporter:
    def __init__(self, stream, fmt):
        self.stream,self.fmt,self.count=stream,fmt,0
        if fmt=='csv':
            self.writer=csv.DictWriter(stream,fieldnames=FIELDS)
            self.writer.writeheader()

    def write(self,result):
        self.count+=1
        if self.fmt=='jsonl':
            self.stream.write(json.dumps(result,ensure_ascii=True)+'\n')
        elif self.fmt=='csv':
            # Escape controls in spreadsheet cells, preserving bytes in match_hex.
            row={k:(json.dumps(v,ensure_ascii=True)[1:-1] if isinstance(v,str) else v) for k,v in result.items()}
            row['source_lines']=','.join(map(str,row['source_lines']))
            row['source_urls']='; '.join(row['source_urls'])
            row['evidence_lines']=','.join(map(str,row['evidence_lines']))
            for key,value in row.items():
                if isinstance(value,str) and value.startswith(('=','+','-','@')):
                    row[key]="'"+value
            self.writer.writerow(row)
        else:
            loc=json.dumps(result['path'],ensure_ascii=True)
            if result['line'] is not None:
                loc+=f":{result['line']}:{result['column']}"
            else:
                loc+=' [whole file/path; no line]'
            self.stream.write(f"{loc} [{result['mode']}/{result['kind']}/{result['category']}] "
                              f"{result['indicator_id']} matched={json.dumps(result['match'],ensure_ascii=True)}\n")
            if result['line_text'] is not None:
                self.stream.write('  line: '+json.dumps(result['line_text'],ensure_ascii=True)+'\n')
            self.stream.write('  evidence: '+result['evidence_status']+'; '+result['note']+'\n')
            if result['evidence_lines']:
                self.stream.write('  required conditions found on lines: '+','.join(map(str,result['evidence_lines']))+'\n')
            if result['source_urls']:
                self.stream.write('  sources: '+' '.join(result['source_urls'])+'\n')


class Progress:
    """Dependency-free stderr progress; share the lock with result/error writes."""
    def __init__(self, enabled, lock, reporter, errors, skipped):
        self.enabled=enabled
        self.lock=lock
        self.reporter,self.errors,self.skipped=reporter,errors,skipped
        self.stream=sys.stderr
        self.terminal=self.stream.isatty()
        self.total=None
        self.done=0
        self.found=0
        self.started=time.monotonic()
        self.last=0.0
        self.width=0

    def clear(self):
        with self.lock:
            if self.enabled and self.terminal and self.width:
                self.stream.write('\r'+' '*self.width+'\r')
                self.stream.flush()
                self.width=0

    def render(self, force=False):
        with self.lock:
            now=time.monotonic()
            # Forced progress on redirected stderr uses occasional plain lines.
            interval=0.1 if self.terminal else 1.0
            if not self.enabled or (not force and now-self.last<interval):
                return
            self.last=now
            elapsed=max(0.001,now-self.started)
            if self.total is None:
                label=f'Discovering files: {self.found} found | {elapsed:.0f}s'
            else:
                ratio=self.done/self.total if self.total else 1.0
                filled=int(24*ratio)
                bar='#'*filled+'-'*(24-filled)
                rate=self.done/elapsed
                eta=f'{(self.total-self.done)/rate:.0f}s' if rate else '?'
                label=(f'[{bar}] {ratio:6.1%} {self.done}/{self.total} files'
                       f' | {self.reporter.count} matches | {self.errors[0]} errors'
                       f' | {self.skipped[0]} skipped | {elapsed:.0f}s | ETA {eta}')
            if self.terminal:
                label=label[:max(1,shutil.get_terminal_size((120,24)).columns-1)]
                self.stream.write('\r'+label+' '*max(0,self.width-len(label)))
                self.width=len(label)
            else:
                self.stream.write(label+'\n')
            self.stream.flush()

    def finish(self):
        with self.lock:
            self.render(force=True)
            if self.enabled and self.terminal:
                self.stream.write('\n')
                self.stream.flush()
                self.width=0


class OutputError(Exception):
    """An output failure must abort scanning, not masquerade as an input error."""


def scan_file(path, root, rules, networks, hashes, path_items, args, emit, error, stop):
    """One worker owns each file; shared compiled rules are read-only."""
    if stop.is_set():
        return
    if args.paths:
        for result in path_matches(path,root,path_items,args):
            if stop.is_set():
                return
            emit(result)
    if args.file_hashes and hashes:
        try:
            digest=hashlib.sha256()
            with path.open('rb') as stream:
                for chunk in iter(lambda:stream.read(1024*1024),b''):
                    if stop.is_set():
                        return
                    digest.update(chunk)
            for item in hashes.get(digest.hexdigest(),[]):
                emit(record(path,'file','sha256',item))
        except OSError as exc:
            error(path,exc)
    modes=['strings','bytes'] if args.mode=='both' else [args.mode]
    for mode in modes:
        if stop.is_set():
            return
        if not rules[mode] and not networks and not args.public_ips:
            continue
        try:
            opener=gzip.open if args.gzip and path.suffix.lower()=='.gz' else open
            options=dict(encoding=args.encoding,errors=args.decode_errors,newline=None) if mode=='strings' else {}
            with opener(path,'rt' if mode=='strings' else 'rb',**options) as stream:
                for result in content_matches(path,stream,mode,rules[mode],networks,args,stop):
                    emit(result)
        except (OSError,UnicodeError,EOFError,zlib.error) as exc:
            error(path,f'{mode}: {exc}')


def parser():
    p=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('directory',type=Path,help='Root directory; all regular files in subfolders are scanned.')
    p.add_argument('--ioc-file',type=Path,default=Path(__file__).with_name('iocs.json'),help='Indicator JSON (default: beside this script).')
    p.add_argument('--mode',choices=['strings','bytes','both'],default='both',help='Decoded str regex, raw bytes regex, or both (default).')
    p.add_argument('--encoding',default='utf-8',help='String-mode file encoding; e.g. utf-16 (default utf-8). Byte mode always scans raw bytes.')
    p.add_argument('--decode-errors',choices=['strict','replace','surrogateescape'],default='surrogateescape',help='String decoding error policy (default surrogateescape).')
    p.add_argument('--ignore-case',action='store_true',help='Case-insensitive content and path matching (bytes: ASCII case only).')
    p.add_argument('--iocs',action=argparse.BooleanOptionalAction,default=True,help='Use extracted indicators (default on).')
    p.add_argument('--file-hashes',action=argparse.BooleanOptionalAction,default=True,help='Compute SHA-256 of original file bytes and compare to IOC hashes (default on).')
    p.add_argument('--hash-text',action='store_true',help='Also search for hexadecimal hash strings inside content (off by default).')
    p.add_argument('--paths',action=argparse.BooleanOptionalAction,default=True,help='Check anchored appliance paths when --appliance-root is supplied (default on).')
    p.add_argument('--appliance-root',type=Path,help='Export directory representing appliance /. Enables location-scoped rules; never guessed from suffixes.')
    p.add_argument('--log-glob',action='append',default=[],metavar='GLOB',help='Treat an additional basename glob as exported NetScaler logs for hunting rules; repeatable.')
    p.add_argument('--heuristics',action='store_true',help='Enable contextual hunting rules and weak path leads. Required file/line conditions remain enforced.')
    p.add_argument('--verified-only',action='store_true',help='Use only catalog entries confirmed in a retrieved primary report; excludes original-script-only entries.')
    p.add_argument('--public-ips',action=argparse.BooleanOptionalAction,default=False,help='Find public unicast IPs using regex + ipaddress validation (default off).')
    ip_only=p.add_mutually_exclusive_group()
    ip_only.add_argument('--public-ips-only',action='store_true',help='Enable public IP checks and disable the IOC catalog, paths and hash checks.')
    ip_only.add_argument('--ioc-ips-only',action='store_true',help='Search only catalog attacker/scanner/password-spray IPs and CIDR ranges; no other IOCs or file hashes.')
    p.add_argument('--ip-version',choices=['4','6','both'],default='both',help='Public IP family (default both). Does not filter IOC addresses.')
    p.add_argument('--string',action='append',default=[],help='Additional literal string; repeatable. Encoded UTF-8 in byte mode.')
    p.add_argument('--regex',action='append',default=[],help='Additional Python regex; repeatable, compiled for str and UTF-8 bytes.')
    p.add_argument('--hex',action='append',default=[],help='Additional literal byte sequence as hex, e.g. 00ff4142; repeatable, byte mode only.')
    p.add_argument('--byte-regex',action='append',default=[],help=r'Additional ASCII bytes regex, e.g. \x00[\x80-\xff]+; repeatable.')
    p.add_argument('--gzip',action='store_true',help='Decompress .gz for content scanning; hashes still use original compressed file bytes.')
    p.add_argument('--exclude',action='append',default=[],metavar='GLOB',help='Skip a relative-path or basename glob (repeatable). Skips matching directories too.')
    p.add_argument('--max-file-mb',type=float,default=0,help='Skip files above this size; 0 means no limit (default).')
    p.add_argument('--workers','--threads',type=int,default=min(8,(os.cpu_count() or 1)+4),metavar='N',help='Parallel file-scanning threads (default: up to 8). Use 1 for sequential scanning.')
    p.add_argument('--progress',action=argparse.BooleanOptionalAction,default=None,help='Show progress on stderr (default: enabled in terminals). --progress forces it; --no-progress hides it.')
    p.add_argument('--format',choices=['text','jsonl','csv'],default='text',help='Result format (default text).')
    p.add_argument('-o','--output',type=Path,help='Write results to a NEW file; refuses to overwrite an existing file.')
    return p


def main(argv=None):
    p=parser()
    args=p.parse_args(argv)
    if not args.directory.is_dir():
        p.error('directory must be an existing directory')
    if args.appliance_root is not None:
        args.appliance_root=args.appliance_root.resolve()
        if not args.appliance_root.is_dir():
            p.error('--appliance-root must be an existing directory representing appliance /')
        try:
            args.directory.resolve().relative_to(args.appliance_root)
        except ValueError:
            p.error('scan directory must be within --appliance-root')
    if args.max_file_mb < 0:
        p.error('--max-file-mb must be nonnegative')
    if args.workers < 1:
        p.error('--workers must be at least 1')
    if args.ioc_ips_only:
        if not args.iocs or args.public_ips or args.string or args.regex or args.hex or args.byte_regex:
            p.error('--ioc-ips-only cannot be combined with --no-iocs, --public-ips, or custom search patterns')
        args.file_hashes=False
        args.paths=False
    if args.mode=='strings' and (args.hex or args.byte_regex):
        p.error('--hex and --byte-regex require --mode bytes or both')
    if any(not value for value in args.string+args.regex+args.hex+args.byte_regex):
        p.error('custom patterns must not be empty')
    if any('\n' in value or '\r' in value for value in args.string):
        p.error('--string matches within one line; newline patterns are not supported')
    try:
        codecs.lookup(args.encoding)
        for value in args.hex:
            data=bytes.fromhex(value)
            if not data or b'\n' in data:
                p.error('--hex must be nonempty and contain no LF byte; matches are line-local')
    except (LookupError,ValueError) as exc:
        p.error(str(exc))
    if args.public_ips_only:
        args.public_ips=True
        args.iocs=False
    items=[]
    try:
        if args.iocs:
            catalog=json.loads(args.ioc_file.read_text(encoding='utf-8-sig'))
            if catalog.get('schema_version') not in (1,2):
                p.error('unsupported IOC catalog schema')
            items=catalog['indicators']
            if args.ioc_ips_only:
                ip_categories={'attacker_ipv4','scanner_ipv4','password_spray_ipv4','password_spray_cidr'}
                items=[item for item in items if item['category'] in ip_categories]
                if not items:
                    p.error('IOC catalog has no supported IP address or CIDR indicators')
        rules,networks,hashes,path_items=compile_rules(items,args)
    except (OSError,ValueError,KeyError,TypeError,re.error,UnicodeError) as exc:
        p.error(f'Unable to load indicators or compile patterns: {exc}')
    root=args.directory.resolve()
    excluded={Path(__file__).resolve(),args.ioc_file.resolve()}
    if args.output:
        excluded.add(args.output.resolve())
    errors=[0]
    skipped=[0]
    files=0
    try:
        output=args.output.open('x',encoding='utf-8',newline='') if args.output else sys.stdout
    except OSError as exc:
        p.error(f'Unable to create output file: {exc}')
    reporter=Reporter(output,args.format)
    lock=threading.RLock()
    stop=threading.Event()
    progress=Progress(args.progress if args.progress is not None else sys.stderr.isatty(),
                      lock,reporter,errors,skipped)
    def error(path,exc):
        with lock:
            errors[0]+=1
            progress.clear()
            print('ERROR '+json.dumps(str(path))+': '+json.dumps(str(exc)),file=sys.stderr)
            progress.render()
    def emit(result):
        with lock:
            if stop.is_set():
                return
            # Clear/redraw only when matches are sharing the console with the bar.
            if not args.output:
                progress.clear()
            try:
                reporter.write(result)
            except (OSError,UnicodeError) as exc:
                stop.set()
                raise OutputError(str(exc)) from exc
            if not args.output:
                progress.render()
    pool=None
    try:
        # Discover first for an accurate denominator. Only paths/sizes are retained;
        # matches are streamed under the output lock, never collected per file.
        candidates=[]
        progress.render(force=True)
        for path,size in iter_files(root,excluded,args.exclude,error,skipped):
            if args.max_file_mb and size>args.max_file_mb*1024*1024:
                skipped[0]+=1
                with lock:
                    progress.clear()
                    print('SKIP size limit: '+json.dumps(str(path)),file=sys.stderr)
                continue
            candidates.append(path)
            progress.found=len(candidates)
            progress.render()
        progress.total=len(candidates)
        progress.started=time.monotonic()
        progress.render(force=True)
        pool=ThreadPoolExecutor(max_workers=args.workers,thread_name_prefix='ioc-scan')
        remaining=iter(candidates)
        pending={}
        def submit_next():
            path=next(remaining,None)
            if path is not None:
                future=pool.submit(scan_file,path,root,rules,networks,hashes,path_items,args,emit,error,stop)
                pending[future]=path
        # Bound outstanding futures; don't enqueue millions of tasks at once.
        for _ in range(min(len(candidates),args.workers*2)):
            submit_next()
        while pending:
            finished,_=wait(pending,timeout=0.1,return_when=FIRST_COMPLETED)
            for future in finished:
                path=pending.pop(future)
                try:
                    future.result()
                except OutputError:
                    raise
                except Exception as exc:
                    error(path,f'Worker failed: {exc}')
                files+=1
                with lock:
                    progress.done=files
                submit_next()
            progress.render()
    finally:
        stop.set()
        if pool is not None:
            # Workers cooperate at line/chunk boundaries; queued work is cancelled.
            pool.shutdown(wait=True,cancel_futures=True)
        progress.finish()
        if args.output:
            output.close()
    print(f'Scanned {files} files; {reporter.count} matches; {skipped[0]} skipped entries; {errors[0]} errors.',file=sys.stderr)
    return 2 if errors[0] else 1 if reporter.count else 0


if __name__=='__main__':
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print('Interrupted: scan incomplete.',file=sys.stderr)
        sys.exit(2)
    except BrokenPipeError:
        sys.exit(2)
    except OutputError as exc:
        print('Output failed: '+json.dumps(str(exc)),file=sys.stderr)
        sys.exit(2)
