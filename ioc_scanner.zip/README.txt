Recursive IOC scanner — reviewed catalog, 2026-10-04

Python 3.10+; standard library only. Keep ioc_scan.py and iocs.json together.
The shell script is treated as evidence, never executed. Files are read-only.

USAGE

From the directory containing the scanner:

  python ioc_scan.py --ioc-file iocs.json --mode both --ignore-case --iocs --workers 8 --progress -o output.txt --format text C:\Evidence

This recursively scans all regular files under C:\Evidence for catalog content
signatures, complete URLs, IPs/domains/ranges and actual SHA-256 file hashes.
--iocs is on by default. Generic filename fragments are not searched.
Keep the scanner package and its reference inventory outside the evidence tree.
The script, selected IOC JSON and current output are automatically excluded.

APPLIANCE EXPORTS AND CONTEXT

For an extracted filesystem whose top level contains var, nsconfig, etc:

  python ioc_scan.py C:\Evidence\appliance --appliance-root C:\Evidence\appliance --mode both --heuristics --gzip --workers 8 --progress -o hunt.txt

--appliance-root maps that directory to appliance /. It enables anchored physical
path matching and content rules restricted to specific appliance locations.
The scan directory must be that root or a directory beneath it.
The root is never guessed from arbitrary path components. With no root supplied,
physical path checks and appliance-location content rules are inactive. Global
payload signatures, hashes, networks and filename-scoped log hunts still work.

/s means precisely the file at <appliance-root>\s, and requires --heuristics.
It cannot match a '/s' switch in text, a folder such as 'scripts', or nested\s.
main.py alone is not an IOC. The actual reported full URL, payload hash, and
reported /var/1.py artifact location are represented separately.
nsgclient18.deb alone is not an IOC. Embedded payload tokens and actual hashes
detect altered or renamed malicious content. A package URI is only a log hunt.
Legitimate customsnmpd and .ns_suidcmd existence alone does not trigger.

--heuristics enables contextual hunting leads, including broad original grep
expressions. It does not disable scope or AND conditions. For example:
  * HTTP_NSC_CLIENTTYPE/LDAP plus execution code must coexist in a file in the
    source web directories; additional report-derived compound signatures can
    detect renamed samples elsewhere.
  * Administration batch detection requires all five commands in the same file.
  * nsepa.deb probe detection requires HTTP 206 with one response byte on the
    same access-log line.
  * Generic grep alternatives from source line 1348 only apply to recognized
    logs, exclude shell_command=, and require --heuristics.

Log rules recognize basenames such as httpaccess*, httperror*, ns.log*, messages*,
nsvpn.log*, sh.log*, and bash.log*, as appropriate to each rule. Use --log-glob
for renamed exports, e.g. --log-glob '*.export'. This deliberately treats those
files as relevant NetScaler logs; it does not parse or validate a log format.

--verified-only restricts the catalog to indicators/signatures confirmed in a
retrieved primary report. Original-script-only values remain in the default
catalog to preserve the supplied checks; their status is visible in every hit.
Report-confirmed means the source reports the value, not certainty of compromise.

IP MODES

Catalog IP addresses/ranges only, retaining attacker/scanner/spray categories:
  python ioc_scan.py C:\Evidence --ioc-file iocs.json --ioc-ips-only --mode both --progress -o ioc-ips.txt

All public IPv4/IPv6 addresses, regardless of the IOC list:
  python ioc_scan.py C:\Evidence --public-ips-only --mode both --progress -o public-ips.txt

Add public IP discovery to a normal IOC scan with --public-ips.
--ip-version 4, 6, or both filters public-IP discovery only.
Candidates are extracted by regex and validated with Python ipaddress. Private,
loopback, link-local, reserved, unspecified and multicast addresses are excluded.
Results follow the Python version's address classifications. Public addresses
are observations, not IOC verdicts. --ioc-ips-only disables hashes and paths and
rejects public-IP or custom-search flags that conflict with it.

CONTENT, HASHES AND OUTPUT

--mode strings scans decoded Python str with str regexes.
--mode bytes scans raw bytes with bytes regexes; catalog text is UTF-8 encoded.
--mode both performs both passes and intentionally reports both forms of a hit.
--encoding sets string decoding (default utf-8); --decode-errors controls errors
(default surrogateescape; alternatives strict or replace).
--ignore-case affects content/path matching; byte case folding is ASCII only.
Some source rules and domains are case-insensitive independently of this flag.

SHA-256 checks compute a digest over the complete original file bytes. They are
on by default, irrespective of string/byte mode. --no-file-hashes disables them.
--hash-text additionally searches for printed digest strings inside file content;
it does not replace real hashing. One hash identifies a vulnerable component,
not malware, and is labeled separately.

--format text, jsonl, or csv selects output (default text).
-o/--output writes a NEW file and refuses to overwrite an existing file.
Without -o, results go to stdout; progress/errors go to stderr.
Results include absolute path, 1-based line/column, matched content, source line,
indicator ID, evidence status, report URLs and rule note. Bytes mode also reports
0-based byte_offset and exact match_hex. Compound rules include evidence_lines
for the required predicates and one anchor match. Hash/path matches refer to the
whole file/path and have no line number. Text lines use universal newlines;
bytes lines split at LF. Individual regexes are line-local. file_all conditions
may span separate lines in one file. Threaded output order is nondeterministic.

CUSTOM SEARCHES

--no-iocs disables the catalog; useful with custom patterns or public IPs.
--string VALUE      Additional literal, repeatable; str and/or UTF-8 bytes.
--regex PATTERN     Additional Python regex, repeatable; str and/or bytes.
--hex 00ff4142      Additional raw literal bytes; requires bytes or both mode.
--byte-regex '\x00[\x80-\xff]+'  Additional ASCII bytes regex, repeatable.

Custom searches are not constrained by catalog context. Multiline literal
patterns and LF-containing --hex patterns are not supported.

PERFORMANCE AND COVERAGE

--workers N / --threads N: parallel files; default up to 8. Use 1 for sequential.
--progress / --no-progress: force/hide progress (default on in a terminal).
Discovery precedes scanning to provide an accurate percentage denominator.
--exclude GLOB: repeatable relative-path or basename exclusions; matching
directories are skipped. --max-file-mb N: skip larger files; 0 means no limit.
--paths / --no-paths enables/disables physical path results. Location constraints
on content rules still apply independently.

--gzip decompresses .gz files for CONTENT checks only; hash checks still operate
on the original compressed file. Byte offsets refer to the decompressed stream.
ZIP/tar/real Debian package members are NOT scanned internally. Extract these
first. A file named .deb that actually contains PHP/plain payload content can
be scanned directly. Encrypted archives are not opened.

Links, junctions and special files are skipped. Empty directories are not reported;
directory-artifact rules report files found beneath that anchored directory.
Windows exports cannot reliably expose all appliance permissions. Live processes,
listeners, firmware history, date baselines and time-correlated crash analysis
are outside this offline scanner. See IOC_RESEARCH.txt and ioc_review_audit.json
for retained and omitted checks. Scan a stable acquired copy: changing files
can give inconsistent content/hash results. Very long lines can consume memory.

Exit codes: 0 no matches; 1 matches; 2 errors/incomplete scan or invalid arguments.
Skipped entries/size limits are counted; read/decoding errors are reported.

PACKAGE

ioc_scan.py             Scanner.
iocs.json               Reviewed schema-2 catalog with per-entry provenance.
ioc_inventory.txt       Values, conditions, sources and status.
ioc_review_audit.json   Original grep lines and disposition of every prior entry.
IOC_RESEARCH.txt        Research decisions and verification limits.
README.txt             This guide.

Validation covers recursive strings/bytes, line/byte offsets, real hashing, IP
modes, boundaries, gzip, threading/progress, I/O errors, anchored paths, compound
conditions, false-positive regressions and provenance. See validation results.
