RECURSIVE IOC SCANNER
====================

Requirements: Python 3.10 or newer. Standard library only; nothing to install.
Keep ioc_scan.py and iocs.json together. Run from the folder containing them,
or use the full path to ioc_scan.py. Source shell script was read, never run.

QUICK START

  python ioc_scan.py "C:\Evidence" --public-ips --format jsonl -o matches.jsonl

Default behavior:
  * Scan multiple files concurrently with up to 8 worker threads.
  * Show a live progress bar when stderr is a terminal.
  * Recursively visit regular files, including hidden files and binary files.
  * Compute the actual SHA-256 of every file and compare against extracted hashes.
  * Search decoded strings AND raw bytes with separate compiled regular expressions.
  * Search known IPs, domains, markers, filenames and paths in file contents.
  * Compare actual relative file paths/ancestor names against known paths/globs.
  * Public IP discovery is OFF until enabled with --public-ips.
  * Broad heuristic expressions are OFF until enabled with --heuristics.

EXAMPLES

  # Parallel scan with 8 workers and an explicitly enabled progress bar:
  python ioc_scan.py "C:\Evidence" --workers 8 --progress --mode both --ignore-case --iocs --format text -o output.txt

  # Known IOCs, both representations, real file hash checks, and public IPs:
  python ioc_scan.py "C:\Evidence" --mode both --public-ips

  # Raw binary scanning, a literal byte sequence, and a bytes regex:
  python ioc_scan.py "C:\Evidence" --mode bytes --hex 00ff4142 --byte-regex "\x00[\x80-\xff]+"

  # Decoded text only; useful for UTF-16 exported logs:
  python ioc_scan.py "C:\Evidence" --mode strings --encoding utf-16

  # Public IPv4 only, without the IOC catalog or file-hash checks:
  python ioc_scan.py "C:\Evidence" --public-ips-only --ip-version 4 --mode both

  # Public IPv6 only, alongside the normal IOC checks:
  python ioc_scan.py "C:\Evidence" --public-ips --ip-version 6

  # Include heuristic regexes, decompress gzip logs, write CSV:
  python ioc_scan.py "C:\Evidence" --heuristics --gzip --format csv -o results.csv

  # Custom literals and regexes, without built-in IOCs:
  python ioc_scan.py "C:\Evidence" --no-iocs --string "suspicious-marker" --regex "token=[A-F0-9]{16}"

  # Optional hash-text search IN ADDITION to actual file-hash comparisons:
  python ioc_scan.py "C:\Evidence" --hash-text

  # Skip folders/files by basename or relative path; optionally cap file size:
  python ioc_scan.py "C:\Evidence" --exclude "reports" --exclude "*.iso" --max-file-mb 500

  # Full flag reference:
  python ioc_scan.py --help

OUTPUT

Every content match reports the absolute path, 1-based line number and column,
matched indicator, matched value, complete matching line, and matching mode.
Multiple occurrences on a line produce separate records. With --mode both,
an ASCII occurrence normally produces both a strings record and a bytes record.

Bytes records also include exact match_hex and a zero-based byte_offset.
Byte-mode lines are separated by LF (0a); the column counts bytes. Binary files
without LF have one line. String-mode columns count decoded characters, and
universal newline handling recognizes LF, CRLF and CR. String byte_offset is null.
For gzip, line numbers and byte offsets refer to the decompressed content.

Actual file-hash matches have kind=sha256, mode=file, and line/column/offset=null:
a whole-file digest has no matching line. Hashing uses original file bytes,
including for compressed files. SHA-256 is enabled by default; --no-file-hashes
disables it. --hash-text separately enables searching for written hex digests.
Path/name matches similarly have no line number and use kind=path, mode=path.

JSONL is recommended for exact machine-readable results. JSON escapes control
characters, so terminal escape sequences in evidence cannot run. Text output also
escapes controls. Byte line_text uses Latin-1 for a reversible one-byte view;
match_hex is the authoritative byte representation. CSV escapes controls and
prefixes formula-like cells to avoid spreadsheet formula interpretation.

Results go to stdout, or --output writes a NEW file (existing files are refused).
Progress summary/errors go to stderr. Output, scanner and selected IOC JSON files
are automatically skipped if inside the scanned directory. Other reports and the
inventory contain indicators and WILL match; keep them outside your evidence tree
or exclude them. Symlinks, Windows reparse points/junctions, and special files are
skipped. No scanned file is changed. Explicit exclusions and size limits are
counted as skips. Read/decoding/traversal errors produce exit code 2.

Exit codes: 0 = no matches; 1 = matches; 2 = error/incomplete scan or bad arguments.

THREADS AND PROGRESS

--workers N (alias --threads N) controls concurrent file scans. The default is
min(8, CPU count + 4); --workers 1 processes one file at a time. Both hash checks
and content checks run inside the file worker. Compiled matching rules are shared
read-only, and a lock serializes output records and error messages so records do
not become mixed together. Matches are streamed rather than buffered per file.
Result ordering between different files is not deterministic with multiple workers.

The scanner first discovers eligible file paths to obtain a total. During this
phase it displays a discovery count. It then displays a file-completion bar,
percentage, completed/total file counts, matches, errors, skips, elapsed time and
an estimated time remaining (fields may be clipped in narrow terminals). Files
with errors still count as completed attempts; errors remain visible and cause
exit code 2. Progress measures files, not bytes; a large file can dominate the
remaining time. The estimate is approximate, based on the completion rate.

Progress uses stderr, keeping stdout and --output results clean. It is enabled
automatically in terminals. Use --progress to force it or --no-progress to disable
it. When forced with redirected stderr, it writes occasional plain status lines
instead of terminal carriage-return updates. No external progress-bar library is
required. Ctrl+C cancels queued work; active workers stop at line/hash-chunk
boundaries after current I/O returns.

Only a bounded number of tasks are submitted at once (twice the worker count).
The discovered path list is held in memory. Increase workers cautiously for slow
disks or very large binary lines; more threads do not guarantee higher throughput.
Python's standard regex processing can be CPU-bound and limited by the GIL.

PUBLIC IP MATCHING

IPV4_REGEX and IPV6_REGEX in the Python file extract candidate addresses as str
or bytes. ipaddress validates them, then public_address() accepts global unicast
addresses and excludes private, loopback, link-local, shared carrier NAT, reserved,
documentation, unspecified and multicast addresses according to Python's bundled
address classification. IPv4-mapped IPv6 checks the embedded IPv4 address.
Special-purpose range classifications can differ with Python releases; prefer a
current Python version when those distinctions matter. Public does not mean
malicious. --ip-version affects public-IP discovery, not known-IP IOC matching.
Only textual IP representations are found, not packed 4-byte/16-byte IP structs.
For specific packed byte sequences use --hex.

EXTRACTION SCOPE AND INTERPRETATION

ioc_inventory.txt provides the human-readable full extracted inventory.
iocs.json provides categorized indicators, matching types, source line references,
notes, source version and SHA-256 of the original supplied script. It can be edited
to add indicators while retaining schema_version=1 and the indicator fields.

Network/hash lists include:
  99 attacker IPv4 addresses
  97 scanner IPv4 addresses (hunting leads)
   1 separately listed password-spray IPv4 address
   3 password-spray /24 ranges
  15 domains
  34 payload/webshell SHA-256 hashes
   1 vulnerable-component SHA-256 hash (not classified as a malware hash)

Additional inventory entries cover named artifacts, paths, filename globs, tokens,
keys, and regexes from the detection logic. The removed pyrlnk.cc spelling and
unspecified shared Cloudflare/CGNAT addresses are not active source indicators.
Source claims, dates and threat attributions were not independently verified.

Matches are investigation leads. Source rules sometimes depend on a specific
directory, file type, time, permission, multiple co-occurring commands, or live
appliance state. The content scanner intentionally searches across the selected
tree; it does not assert the original shell script's compromise verdicts.
--heuristics additionally enables generic PHP, JavaScript, process, log and
configuration expressions; these can match normal code and administration.
The inventory lists appliance-specific contextual checks that are not reproduced.

LIMITATIONS

* Regex and literal content matches are line-local; no multiline matching.
  --hex rejects LF-containing patterns. Custom regexes must not rely on crossing
  a line boundary. Literal byte patterns use --hex, not a search for their printed
  hexadecimal spelling. --regex compiles both str and UTF-8 bytes forms by default.
* Byte matching does not decode UTF-16/32, base64 or URL encodings automatically.
  Use string mode with --encoding for encoded text; select an appropriate encoding
  per run for mixed-encoding evidence. UTF-8 uses surrogateescape by default to
  preserve undecodable bytes; --decode-errors strict reports them as errors.
* Files are streamed by line; peak memory depends on the longest line per worker. A binary
  file with no LF may require memory equal to its full size. --max-file-mb can
  limit this explicitly. Concurrent workers multiply potential line-buffer memory.
  Hashing is always streamed in 1 MiB chunks.
* gzip decompression is opt-in. ZIP, tar and other containers are not extracted;
  extract evidence separately if you need to scan their members. No payload runs.
* Use a stable evidence copy: hashing and content passes read files separately,
  so a file being modified during a scan may yield inconsistent observations.

VALIDATION

Tested with harmless fixtures for real whole-file hash matches (versus hash text),
recursive traversal, binary/NUL bytes, hex and regex matches, line numbers and
offsets, UTF-16, public/non-public IPv4/IPv6, network boundaries, CIDR matching,
source-list completeness, actual paths, gzip, decode errors, and output exclusion.
Also tested actual simultaneous worker execution, single/multiple-worker result
equivalence, output integrity, progress totals, empty scans, worker-count validation,
and continued scanning after an input error.
